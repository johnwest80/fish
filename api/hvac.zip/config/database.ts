export const secret = 'jwfishing!@#$!@#$';
// export const database = 'mongodb://127.0.0.1:27017';
// tslint:disable-next-line:max-line-length
export const database = 'mongodb://techcontinued.documents.azure.com:10255/?ssl=true';
export const dbUsername = 'techcontinued';
export const dbPassword = '9t1IIffM9cpqIiaNguqEMN06ilFfHI4fhqdxU1kxNdgyKHzFAxDwekyCEqu81cyRgALgE50SdvkMSY2gGKQzQg==';
